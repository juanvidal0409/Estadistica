"""
=============================================================
DISTRIBUCIÓN NORMAL — Script de análisis y visualización
 Distribuciones de Probabilidad Continuas
=============================================================
Contexto: Puntajes del examen de admisión a la Universidad
          Nacional de Colombia (Saber Pro / ICFES).
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy.stats import norm
import warnings
warnings.filterwarnings('ignore')

# PARÁMETROS DEL PROBLEMA

# Los puntajes del examen Saber Pro siguen una distribución
# Normal con media 250 y desviación estándar 40 puntos.
mu    = 250.0   # media
sigma = 40.0    # desviación estándar

print("=" * 65)
print("   DISTRIBUCIÓN NORMAL — Puntajes Saber Pro (Colombia)")
print("=" * 65)
print(f"\nParámetros: µ = {mu}, σ = {sigma}")
print(f"X ~ N({mu}, {sigma}²)")


# CÁLCULO DE PROBABILIDADES

print("\n" + "─" * 65)
print("CÁLCULO DE PROBABILIDADES")
print("─" * 65)

# P(X < 220) — estudiante con puntaje bajo
a1 = 220
z1 = (a1 - mu) / sigma
p1_man = norm.cdf(z1)    # usando tabla Z estandarizada
p1_sci = norm.cdf(a1, mu, sigma)
print(f"\n  P(X < {a1}):")
print(f"    Z = ({a1} - {mu}) / {sigma} = {z1:.4f}")
print(f"    P(Z < {z1:.4f}) = {p1_man:.6f}  |  Scipy = {p1_sci:.6f}")

# P(X > 300) — estudiante con puntaje alto
a2 = 300
z2 = (a2 - mu) / sigma
p2_man = 1 - norm.cdf(z2)
p2_sci = norm.sf(a2, mu, sigma)
print(f"\n  P(X > {a2}):")
print(f"    Z = ({a2} - {mu}) / {sigma} = {z2:.4f}")
print(f"    P(Z > {z2:.4f}) = 1 - {norm.cdf(z2):.6f} = {p2_man:.6f}  |  Scipy = {p2_sci:.6f}")

# P(230 < X < 290) — rango de puntaje medio
a3, b3 = 230, 290
z3a = (a3 - mu) / sigma
z3b = (b3 - mu) / sigma
p3_man = norm.cdf(z3b) - norm.cdf(z3a)
p3_sci = norm.cdf(b3, mu, sigma) - norm.cdf(a3, mu, sigma)
print(f"\n  P({a3} < X < {b3}):")
print(f"    Z₁ = ({a3} - {mu}) / {sigma} = {z3a:.4f}")
print(f"    Z₂ = ({b3} - {mu}) / {sigma} = {z3b:.4f}")
print(f"    P({z3a:.4f} < Z < {z3b:.4f}) = {norm.cdf(z3b):.6f} - {norm.cdf(z3a):.6f} = {p3_man:.6f}  |  Scipy = {p3_sci:.6f}")

# Percentil 90
p_perc = 0.90
x_p90_sci  = norm.ppf(p_perc, mu, sigma)
print(f"\n  Percentil 90 (P(X < x) = 0.90):")
print(f"    Z₀.₉₀ = {norm.ppf(p_perc):.4f}")
print(f"    x = µ + Z·σ = {mu} + {norm.ppf(p_perc):.4f}·{sigma} = {x_p90_sci:.2f} puntos")


# REGLA EMPÍRICA (68-95-99.7%)

print("\n" + "─" * 65)
print("VERIFICACIÓN DE LA REGLA EMPÍRICA (68-95-99.7%)")
print("─" * 65)
for k, esperado in [(1, 0.6827), (2, 0.9545), (3, 0.9973)]:
    lo, hi = mu - k*sigma, mu + k*sigma
    prob = norm.cdf(hi, mu, sigma) - norm.cdf(lo, mu, sigma)
    print(f"  µ ± {k}σ = [{lo:.1f}, {hi:.1f}] → P = {prob:.4f}  (esperado ≈ {esperado})")


# GRÁFICO

x_range = np.linspace(mu - 4*sigma, mu + 4*sigma, 1000)
y_pdf   = norm.pdf(x_range, mu, sigma)

fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
fig.suptitle(
    'Distribución Normal — Puntajes Saber Pro\n'
    r'$X \sim \mathcal{N}(250,\ 40^2)$',
    fontsize=13, fontweight='bold', y=1.01
)

# Colores
c_curva   = '#1B4F72'
c_area1   = '#AED6F1'  # P(X < 220)
c_area2   = '#F1948A'  # P(X > 300)
c_area3   = '#A9DFBF'  # P(230 < X < 290)

# — Panel izquierdo: tres regiones de probabilidad —
ax1 = axes[0]
ax1.plot(x_range, y_pdf, color=c_curva, linewidth=2.2)

# Region P(X < 220)
mask1 = x_range < a1
ax1.fill_between(x_range[mask1], y_pdf[mask1], alpha=0.7, color=c_area1,
                 label=f'P(X<{a1})={p1_sci:.4f}')

# Region P(X > 300)
mask2 = x_range > a2
ax1.fill_between(x_range[mask2], y_pdf[mask2], alpha=0.7, color=c_area2,
                 label=f'P(X>{a2})={p2_sci:.4f}')

# Region P(230 < X < 290)
mask3 = (x_range > a3) & (x_range < b3)
ax1.fill_between(x_range[mask3], y_pdf[mask3], alpha=0.6, color=c_area3,
                 label=f'P({a3}<X<{b3})={p3_sci:.4f}')

ax1.axvline(mu, color=c_curva, linestyle='--', linewidth=1, alpha=0.7, label=f'µ = {mu}')
ax1.set_xlabel('Puntaje Saber Pro', fontsize=10)
ax1.set_ylabel('Densidad f(x)', fontsize=10)
ax1.set_title('Función de Densidad con Regiones de Probabilidad', fontsize=10)
ax1.legend(fontsize=8)
ax1.grid(alpha=0.25)

# — Panel derecho: regla empírica —
ax2 = axes[1]
ax2.plot(x_range, y_pdf, color=c_curva, linewidth=2.5)

colores_emp = ['#D6EAF8', '#AED6F1', '#5DADE2']
labels_emp  = [f'µ±3σ  ({mu-3*sigma:.0f}, {mu+3*sigma:.0f})  99.7%',
               f'µ±2σ  ({mu-2*sigma:.0f}, {mu+2*sigma:.0f})  95.4%',
               f'µ±1σ  ({mu-1*sigma:.0f}, {mu+1*sigma:.0f})  68.3%']

for k, c, lab in zip([3, 2, 1], colores_emp, labels_emp):
    lo, hi = mu - k*sigma, mu + k*sigma
    mask = (x_range >= lo) & (x_range <= hi)
    ax2.fill_between(x_range[mask], y_pdf[mask], color=c, alpha=0.85, label=lab)

ax2.axvline(mu, color='#333', linestyle='--', linewidth=1, label=f'µ = {mu}')
ax2.set_xlabel('Puntaje Saber Pro', fontsize=10)
ax2.set_ylabel('Densidad f(x)', fontsize=10)
ax2.set_title('Regla Empírica 68-95-99.7%', fontsize=10)
ax2.legend(fontsize=8)
ax2.grid(alpha=0.25)

plt.tight_layout()
ruta_fig = './figuras/normal_distribucion.png'
plt.savefig(ruta_fig, dpi=150, bbox_inches='tight')
print(f"\n  Figura guardada en: {ruta_fig}")
plt.close()


# RESUMEN COMPARATIVO
print("\n" + "=" * 65)
print("   RESUMEN — Comparación Manual vs. Scipy")
print("=" * 65)
print(f"  {'Medida':<25} {'Manual':>12} {'Scipy':>12} {'Coincide':>10}")
print("  " + "─" * 61)
tol = 1e-8
for nombre, val_m, val_s in [
    (f"P(X < {a1})",       p1_man, p1_sci),
    (f"P(X > {a2})",       p2_man, p2_sci),
    (f"P({a3}<X<{b3})",    p3_man, p3_sci),
]:
    ok = "✓" if abs(val_m - val_s) < tol else "✗"
    print(f"  {nombre:<25} {val_m:>12.6f} {val_s:>12.6f} {ok:>10}")
print("=" * 65)
