"""
=============================================================
DISTRIBUCIÓN BINOMIAL — Script de análisis y visualización
 Distribuciones de Probabilidad Discretas
=============================================================
Contexto: Control de calidad en una línea de producción de
          café empacado en una fábrica colombiana.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy.stats import binom
from scipy.special import comb
import warnings
warnings.filterwarnings('ignore')


# PARÁMETROS DEL PROBLEMA

# En una planta empacadora de café en Medellín, el 15% de los
# paquetes presentan algún defecto de sellado. Se inspeccionan
# 20 paquetes al azar. X = número de paquetes defectuosos.
n = 20        # número de ensayos
p = 0.15      # probabilidad de éxito (paquete defectuoso)
q = 1 - p     # probabilidad de fracaso

print("=" * 60)
print("   DISTRIBUCIÓN BINOMIAL — Control de Calidad en Café")
print("=" * 60)
print(f"\nParámetros: n = {n}, p = {p}, q = {q}")
print(f"X ~ B({n}, {p})")


# TABLA DE DISTRIBUCIÓN DE PROBABILIDADES

print("\n" + "─" * 55)
print(f"{'k':>4}  {'P(X=k) manual':>16}  {'P(X=k) scipy':>14}  {'P(X≤k)':>10}")
print("─" * 55)

k_vals = np.arange(0, n + 1)
pmf_manual = []
pmf_scipy  = []
cdf_scipy  = []

for k in k_vals:
    # Cálculo manual usando la fórmula binomial
    c_nk   = comb(n, k, exact=True)
    p_man  = c_nk * (p ** k) * (q ** (n - k))
    p_sci  = binom.pmf(k, n, p)
    cdf_k  = binom.cdf(k, n, p)
    pmf_manual.append(p_man)
    pmf_scipy.append(p_sci)
    cdf_scipy.append(cdf_k)
    print(f"{k:>4}  {p_man:>16.6f}  {p_sci:>14.6f}  {cdf_k:>10.6f}")

print("─" * 55)
print(f"{'Suma':>4}  {sum(pmf_manual):>16.6f}  {sum(pmf_scipy):>14.6f}")


# MEDIDAS DESCRIPTIVAS

media_manual   = n * p
varianza_manual = n * p * q
desv_manual    = np.sqrt(varianza_manual)

media_scipy    = binom.mean(n, p)
varianza_scipy = binom.var(n, p)
desv_scipy     = binom.std(n, p)

print("\n" + "─" * 55)
print("MEDIDAS DESCRIPTIVAS")
print("─" * 55)
print(f"  Media (µ = np):           Manual = {media_manual:.4f}  |  Scipy = {media_scipy:.4f}")
print(f"  Varianza (σ² = npq):      Manual = {varianza_manual:.4f}  |  Scipy = {varianza_scipy:.4f}")
print(f"  Desv. estándar (σ):       Manual = {desv_manual:.4f}  |  Scipy = {desv_scipy:.4f}")


# PROBABILIDADES ESPECÍFICAS

print("\n" + "─" * 55)
print("PROBABILIDADES DE INTERÉS")
print("─" * 55)

# P(X = 3)
k_esp = 3
p_exacta_man = comb(n, k_esp, exact=True) * (p**k_esp) * (q**(n-k_esp))
p_exacta_sci = binom.pmf(k_esp, n, p)
print(f"  P(X = {k_esp}):   Manual = {p_exacta_man:.6f}  |  Scipy = {p_exacta_sci:.6f}")

# P(X <= 5)
k_acu = 5
p_acum_man = sum(comb(n, k, exact=True) * (p**k) * (q**(n-k)) for k in range(k_acu+1))
p_acum_sci = binom.cdf(k_acu, n, p)
print(f"  P(X ≤ {k_acu}):   Manual = {p_acum_man:.6f}  |  Scipy = {p_acum_sci:.6f}")

# P(X > 5)
p_super_man = 1 - p_acum_man
p_super_sci = binom.sf(k_acu, n, p)
print(f"  P(X > {k_acu}):   Manual = {p_super_man:.6f}  |  Scipy = {p_super_sci:.6f}")

# P(2 <= X <= 6)
p_inter_sci = binom.cdf(6, n, p) - binom.cdf(1, n, p)
print(f"  P(2 ≤ X ≤ 6): Scipy = {p_inter_sci:.6f}")


# GRÁFICO DE BARRAS

colores_base    = '#2E86AB'   # azul acero
color_destacado = '#E84855'   # rojo para k especial
color_acum      = '#F9C74F'   # amarillo para acumulado

fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
fig.suptitle(
    'Distribución Binomial — Control de Calidad en Empaque de Café\n'
    r'$X \sim B(20,\ 0.15)$',
    fontsize=13, fontweight='bold', y=1.01
)

# — Panel izquierdo: PMF —
ax1 = axes[0]
colores = [color_destacado if k == k_esp else colores_base for k in k_vals]
bars = ax1.bar(k_vals, pmf_scipy, color=colores, edgecolor='white', linewidth=0.8, width=0.7)

# Anotar la barra destacada
ax1.annotate(
    f'P(X=3)={p_exacta_sci:.4f}',
    xy=(k_esp, p_exacta_sci),
    xytext=(k_esp + 3, p_exacta_sci + 0.01),
    arrowprops=dict(arrowstyle='->', color='#333'),
    fontsize=9, color='#333'
)
ax1.set_xlabel('k (número de paquetes defectuosos)', fontsize=10)
ax1.set_ylabel('P(X = k)', fontsize=10)
ax1.set_title('Función de Probabilidad (PMF)', fontsize=11)
ax1.set_xticks(k_vals[::2])
ax1.axvline(media_scipy, color='#333', linestyle='--', linewidth=1.2, label=f'µ = {media_scipy:.2f}')
ax1.legend(fontsize=9)
ax1.set_xlim(-0.5, n + 0.5)
ax1.grid(axis='y', alpha=0.3)

# — Panel derecho: CDF —
ax2 = axes[1]
ax2.step(k_vals, cdf_scipy, where='post', color='#2E86AB', linewidth=2.2, label='F(k) = P(X ≤ k)')
ax2.fill_between(k_vals[k_vals <= k_acu], cdf_scipy[:k_acu+1], step='post',
                 alpha=0.25, color=color_acum, label=f'P(X ≤ {k_acu}) = {p_acum_sci:.4f}')
ax2.scatter(k_vals, cdf_scipy, color='#2E86AB', s=30, zorder=5)
ax2.set_xlabel('k', fontsize=10)
ax2.set_ylabel('F(k) = P(X ≤ k)', fontsize=10)
ax2.set_title('Función de Distribución Acumulada (CDF)', fontsize=11)
ax2.legend(fontsize=9)
ax2.set_xlim(-0.5, n + 0.5)
ax2.grid(alpha=0.3)

plt.tight_layout()
ruta_fig = './figuras/binomial_distribucion.png'
plt.savefig(ruta_fig, dpi=150, bbox_inches='tight')
print(f"\n  Figura guardada en: {ruta_fig}")
plt.close()


# RESUMEN COMPARATIVO

print("\n" + "=" * 60)
print("   RESUMEN — Comparación Manual vs. Scipy")
print("=" * 60)
print(f"  {'Medida':<20} {'Manual':>12} {'Scipy':>12} {'Coincide':>10}")
print("  " + "─" * 56)
tol = 1e-8
for nombre, val_m, val_s in [
    ("Media",            media_manual,    media_scipy),
    ("Varianza",         varianza_manual, varianza_scipy),
    ("Desv. estándar",   desv_manual,     desv_scipy),
    ("P(X=3)",           p_exacta_man,    p_exacta_sci),
    ("P(X≤5)",           p_acum_man,      p_acum_sci),
]:
    ok = "✓" if abs(val_m - val_s) < tol else "✗"
    print(f"  {nombre:<20} {val_m:>12.6f} {val_s:>12.6f} {ok:>10}")
print("=" * 60)
