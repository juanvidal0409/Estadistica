"""
=============================================================
DISTRIBUCIÓN DE POISSON — Script de análisis y visualización
 Distribuciones de Probabilidad Discretas
=============================================================
Contexto: Llamadas a un centro de emergencias médicas (SAMU)
          en Santiago de Chile durante una hora pico.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import poisson
import math
import warnings
import matplotlib.patches as mpatches
warnings.filterwarnings('ignore')

# PARÁMETROS DEL PROBLEMA

# El SAMU de Santiago recibe en promedio 8 llamadas por hora
# durante el turno nocturno.
lam = 8.0   # λ = tasa media de llamadas por hora

print("=" * 60)
print("   DISTRIBUCIÓN DE POISSON — Llamadas al SAMU")
print("=" * 60)
print(f"\nParámetro: λ = {lam}")
print(f"X ~ Poisson({lam})")


# TABLA DE DISTRIBUCIÓN DE PROBABILIDADES

k_max = 20   # valor máximo relevante para la tabla
k_vals = np.arange(0, k_max + 1)

print("\n" + "─" * 55)
print(f"{'k':>4}  {'P(X=k) manual':>16}  {'P(X=k) scipy':>14}  {'P(X≤k)':>10}")
print("─" * 55)

pmf_manual = []
pmf_scipy  = []
cdf_scipy  = []

for k in k_vals:
    # Fórmula: P(X=k) = e^{-λ} * λ^k / k!
    p_man = (math.exp(-lam) * (lam ** k)) / math.factorial(k)
    p_sci = poisson.pmf(k, lam)
    cdf_k = poisson.cdf(k, lam)
    pmf_manual.append(p_man)
    pmf_scipy.append(p_sci)
    cdf_scipy.append(cdf_k)
    print(f"{k:>4}  {p_man:>16.6f}  {p_sci:>14.6f}  {cdf_k:>10.6f}")

print("─" * 55)
print(f"{'Suma':>4}  {sum(pmf_manual):>16.6f}  {sum(pmf_scipy):>14.6f}")


# MEDIDAS DESCRIPTIVAS

# Para Poisson: µ = σ² = λ
media_manual    = lam
varianza_manual = lam
desv_manual     = math.sqrt(lam)

media_scipy     = poisson.mean(lam)
varianza_scipy  = poisson.var(lam)
desv_scipy      = poisson.std(lam)

print("\n" + "─" * 55)
print("MEDIDAS DESCRIPTIVAS")
print("─" * 55)
print(f"  Media (µ = λ):          Manual = {media_manual:.4f}  |  Scipy = {media_scipy:.4f}")
print(f"  Varianza (σ² = λ):      Manual = {varianza_manual:.4f}  |  Scipy = {varianza_scipy:.4f}")
print(f"  Desv. estándar (σ):     Manual = {desv_manual:.4f}  |  Scipy = {desv_scipy:.4f}")

# PROBABILIDADES ESPECÍFICAS

print("\n" + "─" * 55)
print("PROBABILIDADES DE INTERÉS")
print("─" * 55)

# P(X = 8) — exactamente la media
k_mod = 8
p_mod_man = (math.exp(-lam) * (lam ** k_mod)) / math.factorial(k_mod)
p_mod_sci = poisson.pmf(k_mod, lam)
print(f"  P(X = {k_mod}):    Manual = {p_mod_man:.6f}  |  Scipy = {p_mod_sci:.6f}")

# P(X <= 6)
k_acu = 6
p_acu_man = sum((math.exp(-lam) * (lam**k)) / math.factorial(k) for k in range(k_acu+1))
p_acu_sci = poisson.cdf(k_acu, lam)
print(f"  P(X ≤ {k_acu}):    Manual = {p_acu_man:.6f}  |  Scipy = {p_acu_sci:.6f}")

# P(X >= 12)
k_min = 12
p_ge_man = sum((math.exp(-lam) * (lam**k)) / math.factorial(k) for k in range(k_min, k_max+1))
p_ge_sci = poisson.sf(k_min - 1, lam)
print(f"  P(X ≥ {k_min}):   Manual ≈ {p_ge_man:.6f}  |  Scipy = {p_ge_sci:.6f}")

# P(5 <= X <= 11)
p_inter_sci = poisson.cdf(11, lam) - poisson.cdf(4, lam)
print(f"  P(5 ≤ X ≤ 11): Scipy = {p_inter_sci:.6f}")


# GRÁFICO

color_base  = '#5C6BC0'   # índigo
color_dest  = '#EF5350'   # rojo para la moda
color_acum  = '#80CBC4'   # verde-azul para acumulado

fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
fig.suptitle(
    'Distribución de Poisson — Llamadas al SAMU (Santiago)\n'
    r'$X \sim \mathrm{Poisson}(\lambda=8)$',
    fontsize=13, fontweight='bold', y=1.01
)

# — Panel izquierdo: PMF —
ax1 = axes[0]
colores_barras = [color_dest if k == k_mod else color_base for k in k_vals]
ax1.bar(k_vals, pmf_scipy, color=colores_barras, edgecolor='white', linewidth=0.8, width=0.7)
ax1.axvline(lam, color='#FFA726', linestyle='--', linewidth=1.5, label=f'λ = µ = {lam:.0f}')

# Rango ±σ
ax1.axvspan(lam - desv_scipy, lam + desv_scipy, alpha=0.12, color='#FFA726', label=f'µ ± σ = [{lam-desv_scipy:.2f}, {lam+desv_scipy:.2f}]')
ax1.set_xlabel('k (número de llamadas)', fontsize=10)
ax1.set_ylabel('P(X = k)', fontsize=10)
ax1.set_title('Función de Probabilidad (PMF)', fontsize=11)
ax1.legend(fontsize=8)
ax1.set_xlim(-0.5, k_max + 0.5)
ax1.grid(axis='y', alpha=0.3)

patch_dest = plt.Rectangle((0,0),1,1, color=color_dest, label=f'P(X={k_mod}) = {p_mod_sci:.4f}')
ax1.legend(handles=[patch_dest,
                    plt.Line2D([0],[0], color='#FFA726', linestyle='--', label=f'λ = {lam}'),
                    mpatches.Patch(color='#FFA726', alpha=0.3, label='µ ± σ')
                    ], fontsize=8)


# — Panel derecho: CDF escalón —
ax2 = axes[1]
ax2.step(k_vals, cdf_scipy, where='post', color=color_base, linewidth=2.2)
ax2.fill_between(k_vals[k_vals <= k_acu], cdf_scipy[:k_acu+1],
                 step='post', alpha=0.30, color='#FFA726',
                 label=f'P(X ≤ {k_acu}) = {p_acu_sci:.4f}')
ax2.scatter(k_vals, cdf_scipy, s=25, color=color_base, zorder=5)
ax2.axhline(p_acu_sci, color='#FFA726', linestyle=':', linewidth=1)
ax2.set_xlabel('k', fontsize=10)
ax2.set_ylabel('F(k) = P(X ≤ k)', fontsize=10)
ax2.set_title('Función de Distribución Acumulada (CDF)', fontsize=11)
ax2.legend(fontsize=9)
ax2.set_xlim(-0.5, k_max + 0.5)
ax2.grid(alpha=0.3)

plt.tight_layout()
ruta_fig = './figuras/poisson_distribucion.png'
plt.savefig(ruta_fig, dpi=150, bbox_inches='tight')
print(f"\n  Figura guardada en: {ruta_fig}")
plt.close()

# RESUMEN COMPARATIVO

print("\n" + "=" * 60)
print("   RESUMEN — Comparación Manual vs. Scipy")
print("=" * 60)
print(f"  {'Medida':<20} {'Manual':>12} {'Scipy':>12} {'Coincide':>10}")
print("  " + "─" * 56)
tol = 1e-8
for nombre, val_m, val_s in [
    ("Media",          media_manual,  media_scipy),
    ("Varianza",       varianza_manual, varianza_scipy),
    ("Desv. estándar", desv_manual,   desv_scipy),
    (f"P(X={k_mod})",  p_mod_man,     p_mod_sci),
    (f"P(X≤{k_acu})",  p_acu_man,     p_acu_sci),
]:
    ok = "✓" if abs(val_m - val_s) < tol else "✗"
    print(f"  {nombre:<20} {val_m:>12.6f} {val_s:>12.6f} {ok:>10}")
print("=" * 60)
