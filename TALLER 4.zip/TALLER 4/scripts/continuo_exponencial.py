"""
=============================================================
DISTRIBUCIÓN EXPONENCIAL — Script de análisis y visualización
 Distribuciones de Probabilidad Continuas
=============================================================
Contexto: Tiempo de vida útil (en años) de los medidores de
          agua instalados por empresas de servicios públicos
          en ciudades colombianas (EPM, EAAB, etc.)
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import expon
import math
import warnings
warnings.filterwarnings('ignore')

# PARÁMETROS DEL PROBLEMA

# Los medidores de agua fallan a una tasa de λ = 0.2 fallas/año,
# lo que equivale a una vida media de µ = 1/λ = 5 años.
lam = 0.2        # tasa de falla (fallas por año)
mu  = 1 / lam    # media = vida útil promedio

print("=" * 65)
print("   DISTRIBUCIÓN EXPONENCIAL — Vida Útil de Medidores de Agua")
print("=" * 65)
print(f"\nParámetros: λ = {lam} fallas/año,  µ = 1/λ = {mu:.1f} años")
print(f"X ~ Exp({lam})")


# MEDIDAS DESCRIPTIVAS

media_man    = 1 / lam
varianza_man = 1 / (lam ** 2)
desv_man     = math.sqrt(varianza_man)

# scipy usa scale = 1/λ
media_sci    = expon.mean(scale=mu)
varianza_sci = expon.var(scale=mu)
desv_sci     = expon.std(scale=mu)

print("\n" + "─" * 65)
print("MEDIDAS DESCRIPTIVAS")
print("─" * 65)
print(f"  Media (µ = 1/λ):          Manual = {media_man:.4f}  |  Scipy = {media_sci:.4f}")
print(f"  Varianza (σ² = 1/λ²):     Manual = {varianza_man:.4f}  |  Scipy = {varianza_sci:.4f}")
print(f"  Desv. estándar (σ = 1/λ): Manual = {desv_man:.4f}  |  Scipy = {desv_sci:.4f}")


# CÁLCULO DE PROBABILIDADES
print("\n" + "─" * 65)
print("CÁLCULO DE PROBABILIDADES")
print("─" * 65)

# P(X > 3) — medidor dura más de 3 años
a1 = 3.0
p1_man = math.exp(-lam * a1)                      # P(X > a) = e^{-λa}
p1_sci = expon.sf(a1, scale=mu)
print(f"\n  P(X > {a1}):")
print(f"    = e^(-{lam}·{a1}) = e^(-{lam*a1}) = {p1_man:.6f}  |  Scipy = {p1_sci:.6f}")

# P(X < 2) — medidor falla antes de 2 años
a2 = 2.0
p2_man = 1 - math.exp(-lam * a2)                  # F(x) = 1 - e^{-λx}
p2_sci = expon.cdf(a2, scale=mu)
print(f"\n  P(X < {a2}):")
print(f"    = 1 - e^(-{lam}·{a2}) = 1 - e^(-{lam*a2}) = {p2_man:.6f}  |  Scipy = {p2_sci:.6f}")

# P(4 < X < 8) — medidor dura entre 4 y 8 años
a3, b3 = 4.0, 8.0
p3_man = math.exp(-lam * a3) - math.exp(-lam * b3)
p3_sci = expon.cdf(b3, scale=mu) - expon.cdf(a3, scale=mu)
print(f"\n  P({a3} < X < {b3}):")
print(f"    = e^(-{lam}·{a3}) - e^(-{lam}·{b3})")
print(f"    = {math.exp(-lam*a3):.6f} - {math.exp(-lam*b3):.6f} = {p3_man:.6f}  |  Scipy = {p3_sci:.6f}")


# PROPIEDAD DE FALTA DE MEMORIA (verificación numérica)

print("\n" + "─" * 65)
print("PROPIEDAD DE FALTA DE MEMORIA")
print("─" * 65)
s, t = 3.0, 2.0   # "dado que ya duró 3 años, ¿cuánto más durará?"

# P(X > s+t | X > s) = P(X > t)
p_cond_lhs = math.exp(-lam * (s + t)) / math.exp(-lam * s)  # = e^{-λt}
p_cond_rhs = math.exp(-lam * t)

print(f"\n  P(X > {s+t} | X > {s})  =  P(X > {t})")
print(f"\n  Lado izquierdo:")
print(f"    P(X > {s} + {t}) / P(X > {s})")
print(f"    = e^(-{lam}·{s+t}) / e^(-{lam}·{s})")
print(f"    = {math.exp(-lam*(s+t)):.6f} / {math.exp(-lam*s):.6f}")
print(f"    = {p_cond_lhs:.6f}")
print(f"\n  Lado derecho:")
print(f"    P(X > {t}) = e^(-{lam}·{t}) = {p_cond_rhs:.6f}")
print(f"\n  ¿Coinciden? {'✓ SÍ' if abs(p_cond_lhs - p_cond_rhs) < 1e-10 else '✗ NO'}")
print(f"  → Un medidor que ya lleva {s} años en servicio tiene la MISMA")
print(f"    probabilidad de durar {t} años más que uno recién instalado.")


# GRÁFICO: PDF + CDF

x_range = np.linspace(0, 25, 1000)
y_pdf   = expon.pdf(x_range, scale=mu)
y_cdf   = expon.cdf(x_range, scale=mu)

fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
fig.suptitle(
    'Distribución Exponencial — Vida Útil de Medidores de Agua\n'
    r'$X \sim \mathrm{Exp}(\lambda=0.2)\ ,\quad \mu = 5$ años',
    fontsize=13, fontweight='bold', y=1.01
)

c_curva = '#1A5276'
c_a1    = '#A9CCE3'  # P(X > 3)
c_a2    = '#FAD7A0'  # P(X < 2)
c_a3    = '#A9DFBF'  # P(4 < X < 8)

# — Panel izquierdo: PDF con áreas sombreadas —
ax1 = axes[0]
ax1.plot(x_range, y_pdf, color=c_curva, linewidth=2.2, label='f(x) = λ·e^{-λx}')

mask1 = x_range > a1
ax1.fill_between(x_range[mask1], y_pdf[mask1], alpha=0.7, color=c_a1,
                 label=f'P(X>{a1})={p1_sci:.4f}')
mask2 = x_range < a2
ax1.fill_between(x_range[mask2], y_pdf[mask2], alpha=0.7, color=c_a2,
                 label=f'P(X<{a2})={p2_sci:.4f}')
mask3 = (x_range > a3) & (x_range < b3)
ax1.fill_between(x_range[mask3], y_pdf[mask3], alpha=0.6, color=c_a3,
                 label=f'P({a3}<X<{b3})={p3_sci:.4f}')
ax1.axvline(mu, color='#E74C3C', linestyle='--', linewidth=1.3, label=f'µ = {mu:.0f} años')

ax1.set_xlabel('Tiempo (años)', fontsize=10)
ax1.set_ylabel('Densidad f(x)', fontsize=10)
ax1.set_title('Función de Densidad de Probabilidad', fontsize=11)
ax1.legend(fontsize=8)
ax1.set_xlim(0, 20)
ax1.grid(alpha=0.25)

# — Panel derecho: CDF —
ax2 = axes[1]
ax2.plot(x_range, y_cdf, color='#1A5276', linewidth=2.5, label='F(x) = 1 - e^{-λx}')
ax2.fill_between(x_range[x_range < a2], y_cdf[x_range < a2], alpha=0.4, color=c_a2,
                 label=f'F({a2})={p2_sci:.4f}')
ax2.axhline(0.95, color='#E74C3C', linestyle=':', linewidth=1.2, label='F(x) = 0.95')
x_095 = expon.ppf(0.95, scale=mu)
ax2.axvline(x_095, color='#E74C3C', linestyle=':', linewidth=1.2)
ax2.annotate(f'x={x_095:.2f}', xy=(x_095, 0.95), xytext=(x_095+1, 0.85),
             arrowprops=dict(arrowstyle='->', color='#E74C3C'), fontsize=9, color='#E74C3C')
ax2.set_xlabel('Tiempo (años)', fontsize=10)
ax2.set_ylabel('F(x) = P(X ≤ x)', fontsize=10)
ax2.set_title('Función de Distribución Acumulada', fontsize=11)
ax2.legend(fontsize=9)
ax2.set_xlim(0, 20)
ax2.grid(alpha=0.25)

plt.tight_layout()
ruta_fig = './figuras/exponencial_distribucion.png'
plt.savefig(ruta_fig, dpi=150, bbox_inches='tight')
print(f"\n  Figura guardada en: {ruta_fig}")
plt.close()

# RESUMEN COMPARATIVO

print("\n" + "=" * 65)
print("   RESUMEN — Comparación Manual vs. Scipy")
print("=" * 65)
print(f"  {'Medida':<25} {'Manual':>12} {'Scipy':>12} {'Coincide':>10}")
print("  " + "─" * 61)
tol = 1e-8
for nombre, val_m, val_s in [
    ("Media",               media_man,    media_sci),
    ("Varianza",            varianza_man, varianza_sci),
    ("Desv. estándar",      desv_man,     desv_sci),
    (f"P(X > {a1})",        p1_man,       p1_sci),
    (f"P(X < {a2})",        p2_man,       p2_sci),
    (f"P({a3}<X<{b3})",     p3_man,       p3_sci),
]:
    ok = "✓" if abs(val_m - val_s) < tol else "✗"
    print(f"  {nombre:<25} {val_m:>12.6f} {val_s:>12.6f} {ok:>10}")
print("=" * 65)
