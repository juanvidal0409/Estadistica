"""

Contexto: Control de calidad en una fábrica de electrónicos.
  X = número de defectos en la pantalla (0, 1, 2)
  Y = número de defectos en la batería   (0, 1, 2)

Autor: Juan Esteban Vidal Cabezas 20241020059 - Probabilidad y Estadística
=============================================================
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from fractions import Fraction

# 1. TABLA DE PROBABILIDAD CONJUNTA  P(X = x, Y = y)
# Filas → X = 0, 1, 2   |   Columnas → Y = 0, 1, 2
joint = np.array([
    [0.20, 0.10, 0.05],   # X = 0
    [0.15, 0.20, 0.08],   # X = 1
    [0.07, 0.10, 0.05],   # X = 2
])

x_vals = np.array([0, 1, 2])  # valores posibles de X
y_vals = np.array([0, 1, 2])  # valores posibles de Y

print("=" * 60)
print("  APLICACIÓN 1 — PROBABILIDAD CONJUNTA DISCRETA")
print("  Control de calidad: defectos en pantalla (X) y batería (Y)")
print("=" * 60)

# 
# 2. VERIFICACIÓN: la suma total debe ser 1
# 
total = joint.sum()
print(f"\n[VERIFICACIÓN] Suma de todas las probabilidades: {total:.4f}")
assert abs(total - 1.0) < 1e-9, "¡Error: la tabla no suma 1!"
print("  ✓ La tabla es una distribución de probabilidad válida.\n")

# 
# 3. PROBABILIDADES MARGINALES
# P_X(x) = Σ_y P(X=x, Y=y)   → suma por filas
# P_Y(y) = Σ_x P(X=x, Y=y)   → suma por columnas

marginal_X = joint.sum(axis=1)   # suma de cada fila
marginal_Y = joint.sum(axis=0)   # suma de cada columna

print("─" * 60)
print("  PROBABILIDADES MARGINALES")
print("─" * 60)
print(f"\n  P_X(x) — distribución marginal de X (defectos pantalla):")
for x, p in zip(x_vals, marginal_X):
    print(f"    P(X = {x}) = {p:.4f}")

print(f"\n  P_Y(y) — distribución marginal de Y (defectos batería):")
for y, p in zip(y_vals, marginal_Y):
    print(f"    P(Y = {y}) = {p:.4f}")

# 4. VALORES ESPERADOS Y VARIANZAS

E_X = np.sum(x_vals * marginal_X)
E_Y = np.sum(y_vals * marginal_Y)
Var_X = np.sum((x_vals ** 2) * marginal_X) - E_X**2
Var_Y = np.sum((y_vals ** 2) * marginal_Y) - E_Y**2

print(f"\n─" * 60 if False else "")
print("\n─" * 1 + "─" * 59)
print("  MEDIDAS DE RESUMEN")
print("─" * 60)
print(f"  E[X] = {E_X:.4f}   Var(X) = {Var_X:.4f}")
print(f"  E[Y] = {E_Y:.4f}   Var(Y) = {Var_Y:.4f}")


# 5. PROBABILIDADES CONDICIONALES
# P(X = x | Y = y) = P(X=x, Y=y) / P_Y(y)
print("\n" + "─" * 60)
print("  PROBABILIDADES CONDICIONALES  P(X = x | Y = y)")
print("─" * 60)

for y_idx, y in enumerate(y_vals):
    print(f"\n  Dado Y = {y}  [P(Y={y}) = {marginal_Y[y_idx]:.4f}]:")
    for x_idx, x in enumerate(x_vals):
        cond = joint[x_idx, y_idx] / marginal_Y[y_idx]
        print(f"    P(X = {x} | Y = {y}) = {joint[x_idx, y_idx]:.4f} / "
              f"{marginal_Y[y_idx]:.4f} = {cond:.4f}")

# P(Y = y | X = x)
print("\n" + "─" * 60)
print("  PROBABILIDADES CONDICIONALES  P(Y = y | X = x)")
print("─" * 60)

for x_idx, x in enumerate(x_vals):
    print(f"\n  Dado X = {x}  [P(X={x}) = {marginal_X[x_idx]:.4f}]:")
    for y_idx, y in enumerate(y_vals):
        cond = joint[x_idx, y_idx] / marginal_X[x_idx]
        print(f"    P(Y = {y} | X = {x}) = {joint[x_idx, y_idx]:.4f} / "
              f"{marginal_X[x_idx]:.4f} = {cond:.4f}")


# 6. PROBABILIDAD ESPECÍFICA: P(X + Y = k)

print("\n" + "─" * 60)
print("  PROBABILIDAD DE LA SUMA  P(X + Y = k)")
print("─" * 60)

sum_probs = {}
for x_idx, x in enumerate(x_vals):
    for y_idx, y in enumerate(y_vals):
        k = int(x + y)
        sum_probs[k] = sum_probs.get(k, 0) + joint[x_idx, y_idx]

for k in sorted(sum_probs):
    print(f"  P(X + Y = {k}) = {sum_probs[k]:.4f}")

print(f"\n  Verificación: Σ P(X+Y=k) = {sum(sum_probs.values()):.4f}")

# Ejemplo especial: P(X + Y ≤ 2)
prob_leq2 = sum(v for k, v in sum_probs.items() if k <= 2)
print(f"\n  P(X + Y ≤ 2) = {prob_leq2:.4f}")
print("  → El 70% de los dispositivos tiene a lo sumo 2 defectos combinados.")

# 7. COVARIANZA E INDEPENDENCIA

E_XY = sum(x_vals[i] * y_vals[j] * joint[i, j]
           for i in range(3) for j in range(3))
cov = E_XY - E_X * E_Y
corr = cov / (np.sqrt(Var_X) * np.sqrt(Var_Y))

print("\n" + "─" * 60)
print("  COVARIANZA Y CORRELACIÓN")
print("─" * 60)
print(f"  E[XY]      = {E_XY:.4f}")
print(f"  Cov(X, Y)  = {cov:.4f}")
print(f"  ρ(X, Y)    = {corr:.4f}")
if abs(corr) < 0.1:
    print("  → X e Y están prácticamente sin correlación lineal.")
elif corr > 0:
    print("  → Correlación positiva: más defectos en pantalla suelen")
    print("    coincidir con más defectos en batería.")
else:
    print("  → Correlación negativa.")


# 8. VISUALIZACIONES

fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle("Probabilidad Conjunta Discreta — Defectos en Electrónicos",
             fontsize=14, fontweight='bold', y=1.01)

# 8a. Mapa de calor de la distribución conjunta
ax = axes[0]
im = ax.imshow(joint, cmap='YlOrRd', vmin=0, vmax=0.25)
ax.set_xticks(range(3)); ax.set_xticklabels(y_vals)
ax.set_yticks(range(3)); ax.set_yticklabels(x_vals)
ax.set_xlabel("Y (defectos batería)", fontsize=11)
ax.set_ylabel("X (defectos pantalla)", fontsize=11)
ax.set_title("P(X, Y) — Distribución Conjunta", fontsize=11)
for i in range(3):
    for j in range(3):
        ax.text(j, i, f"{joint[i, j]:.2f}", ha='center', va='center',
                fontsize=13, fontweight='bold',
                color='black' if joint[i, j] < 0.18 else 'white')
plt.colorbar(im, ax=ax, shrink=0.8)

# 8b. Marginales en barras
ax2 = axes[1]
width = 0.35
bars1 = ax2.bar(x_vals - width/2, marginal_X, width,
                label='P_X(x) — Pantalla', color='steelblue', alpha=0.85)
bars2 = ax2.bar(y_vals + width/2, marginal_Y, width,
                label='P_Y(y) — Batería', color='tomato', alpha=0.85)
ax2.set_xticks([0, 1, 2])
ax2.set_xlabel("Número de defectos", fontsize=11)
ax2.set_ylabel("Probabilidad", fontsize=11)
ax2.set_title("Distribuciones Marginales", fontsize=11)
ax2.legend(); ax2.set_ylim(0, 0.55)
for bar in bars1:
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
             f"{bar.get_height():.2f}", ha='center', fontsize=10)
for bar in bars2:
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
             f"{bar.get_height():.2f}", ha='center', fontsize=10)

# 8c. P(X + Y = k)
ax3 = axes[2]
ks = sorted(sum_probs.keys())
ps = [sum_probs[k] for k in ks]
bars3 = ax3.bar(ks, ps, color='mediumseagreen', alpha=0.85, width=0.5)
ax3.set_xticks(ks)
ax3.set_xlabel("k = X + Y (total defectos)", fontsize=11)
ax3.set_ylabel("Probabilidad", fontsize=11)
ax3.set_title("Distribución de X + Y", fontsize=11)
ax3.set_ylim(0, 0.45)
for bar in bars3:
    ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.008,
             f"{bar.get_height():.3f}", ha='center', fontsize=10)

plt.tight_layout()
plt.savefig("/home/claude/fig_discreto.png", dpi=150, bbox_inches='tight')
plt.close()
print("\n  [✓] Figura guardada: fig_discreto.png")
print("\n" + "=" * 60)
print("  FIN DE LA APLICACIÓN 1 — CASO DISCRETO")
print("=" * 60)
