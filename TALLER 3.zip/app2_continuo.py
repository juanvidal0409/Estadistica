"""
=============================================================
APLICACIÓN 2: PROBABILIDAD CONJUNTA — CASO CONTINUO
=============================================================
Contexto: Tiempo de vida (en años) de dos componentes críticos
  de un sistema de energía solar.
  X = vida útil del panel solar   (0 ≤ x ≤ 2)
  Y = vida útil del inversor      (0 ≤ y ≤ 2)

Función de densidad conjunta:
  f(x, y) = (3/32)(x² + y²),   0 ≤ x ≤ 2,  0 ≤ y ≤ 2

Autor: Juan Esteban vidal Cabezas 20241020059 — Probabilidad y Estadística
=============================================================
"""

import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D   # noqa: F401


# 1. DEFINICIÓN SIMBÓLICA

x, y = sp.symbols('x y', real=True, positive=True)

f = sp.Rational(3, 32) * (x**2 + y**2)     # f(x,y) = (3/32)(x²+y²)
region = [(x, 0, 2), (y, 0, 2)]             # dominio: [0,2]×[0,2]

print("=" * 65)
print("  APLICACIÓN 2 — PROBABILIDAD CONJUNTA CONTINUA")
print("  Sistema fotovoltaico: vida útil del panel (X) e inversor (Y)")
print("=" * 65)
print(f"\n  f(x, y) = {f}      con  0 ≤ x ≤ 2,  0 ≤ y ≤ 2")


# 2. VERIFICACIÓN ∬ f(x,y) dx dy = 1

integral_total = sp.integrate(sp.integrate(f, (x, 0, 2)), (y, 0, 2))
print("\n" + "─" * 65)
print("  VERIFICACIÓN DE VALIDEZ")
print("─" * 65)
print(f"  ∬ f(x,y) dx dy = {integral_total}  →  {'✓ VÁLIDA' if integral_total == 1 else '✗ INVÁLIDA'}")

# 3. DENSIDADES MARGINALES

f_X = sp.integrate(f, (y, 0, 2))     # f_X(x) = ∫₀² f(x,y) dy
f_Y = sp.integrate(f, (x, 0, 2))     # f_Y(y) = ∫₀² f(x,y) dx

f_X_simplified = sp.simplify(f_X)
f_Y_simplified = sp.simplify(f_Y)

print("\n" + "─" * 65)
print("  FUNCIONES DE DENSIDAD MARGINALES")
print("─" * 65)
print(f"\n  f_X(x) = ∫₀² f(x,y) dy = {f_X_simplified}")
print(f"         válida para  0 ≤ x ≤ 2")

print(f"\n  f_Y(y) = ∫₀² f(x,y) dx = {f_Y_simplified}")
print(f"         válida para  0 ≤ y ≤ 2")

# Verificar que las marginales integran a 1
check_fX = sp.integrate(f_X, (x, 0, 2))
check_fY = sp.integrate(f_Y, (y, 0, 2))
print(f"\n  ∫ f_X(x) dx = {check_fX}  ✓" if check_fX == 1 else f"  ∫ f_X(x) dx = {check_fX}")
print(f"  ∫ f_Y(y) dy = {check_fY}  ✓" if check_fY == 1 else f"  ∫ f_Y(y) dy = {check_fY}")


# 4. VALORES ESPERADOS Y VARIANZAS

E_X_sym = sp.integrate(x * f_X, (x, 0, 2))
E_Y_sym = sp.integrate(y * f_Y, (y, 0, 2))
E_X2    = sp.integrate(x**2 * f_X, (x, 0, 2))
E_Y2    = sp.integrate(y**2 * f_Y, (y, 0, 2))
Var_X_sym = E_X2 - E_X_sym**2
Var_Y_sym = E_Y2 - E_Y_sym**2

print("\n" + "─" * 65)
print("  MEDIDAS DE RESUMEN")
print("─" * 65)
print(f"  E[X] = {E_X_sym} ≈ {float(E_X_sym):.4f} años")
print(f"  E[Y] = {E_Y_sym} ≈ {float(E_Y_sym):.4f} años")
print(f"  Var(X) = {sp.simplify(Var_X_sym)} ≈ {float(Var_X_sym):.4f}")
print(f"  Var(Y) = {sp.simplify(Var_Y_sym)} ≈ {float(Var_Y_sym):.4f}")


# 5. PROBABILIDAD SOBRE UNA REGIÓN
#    P(X ≤ 1, Y ≤ 1)  — ambos componentes fallan en el primer año

P1 = sp.integrate(sp.integrate(f, (x, 0, 1)), (y, 0, 1))
print("\n" + "─" * 65)
print("  PROBABILIDADES SOBRE REGIONES ESPECÍFICAS")
print("─" * 65)
print(f"\n  P(X ≤ 1, Y ≤ 1) = {P1} ≈ {float(P1):.4f}")
print("  → Solo el 9.4% de los sistemas tienen ambos componentes")
print("    con falla en el primer año.")

# P(X + Y > 2) — la suma de vidas supera 2 años
#   Región: triángulo en [0,2]×[0,2] donde x+y > 2
#   Se integra como: x en [0,2], y en [max(0, 2-x), 2]
P2 = sp.integrate(
    sp.integrate(f, (y, 2 - x, 2)),
    (x, 0, 2)
)
print(f"\n  P(X + Y > 2) = {sp.simplify(P2)} ≈ {float(P2):.4f}")
print("  → El 62.5% de los sistemas tiene una vida combinada mayor a 2 años.")

# P(1 ≤ X ≤ 2, 0 ≤ Y ≤ 1)
P3 = sp.integrate(sp.integrate(f, (x, 1, 2)), (y, 0, 1))
print(f"\n  P(1 ≤ X ≤ 2, 0 ≤ Y ≤ 1) = {sp.simplify(P3)} ≈ {float(P3):.4f}")
print("  → Prob. de que el panel dure más de 1 año pero el inversor menos.")

# 6. DENSIDAD CONDICIONAL f(y|x)

f_Y_given_X = f / f_X              # f(y|x) = f(x,y) / f_X(x)
f_Y_given_X_s = sp.simplify(f_Y_given_X)

print("\n" + "─" * 65)
print("  DENSIDAD CONDICIONAL  f(y | x)")
print("─" * 65)
print(f"\n  f(y | x) = f(x,y) / f_X(x)")
print(f"           = {f_Y_given_X_s}")
print(f"  Verificación con x=1:")
x_val = 1
f_cond_check = sp.integrate(f_Y_given_X_s.subs(x, x_val), (y, 0, 2))
print(f"    ∫₀² f(y|x=1) dy = {sp.simplify(f_cond_check)} ✓")


# 7. INDEPENDENCIA

producto = sp.expand(f_X_simplified * f_Y_simplified)
f_joint_expanded = sp.expand(f)
independientes = sp.simplify(producto - f_joint_expanded) == 0

print("\n" + "─" * 65)
print("  VERIFICACIÓN DE INDEPENDENCIA")
print("─" * 65)
print(f"  f_X(x) · f_Y(y) = {sp.expand(producto)}")
print(f"  f(x, y)          = {f_joint_expanded}")
print(f"  ¿Son iguales? {'NO' if not independientes else 'SÍ'}")
print("  → X e Y NO son independientes: el comportamiento de un")
print("    componente afecta la información sobre el otro.")

# 8. COVARIANZA

E_XY_sym = sp.integrate(sp.integrate(x * y * f, (x, 0, 2)), (y, 0, 2))
Cov_sym  = E_XY_sym - E_X_sym * E_Y_sym
Corr_sym = Cov_sym / sp.sqrt(Var_X_sym * Var_Y_sym)

print("\n" + "─" * 65)
print("  COVARIANZA Y CORRELACIÓN")
print("─" * 65)
print(f"  E[XY]     = {E_XY_sym} ≈ {float(E_XY_sym):.4f}")
print(f"  Cov(X,Y)  = {sp.simplify(Cov_sym)} ≈ {float(Cov_sym):.6f}")
print(f"  ρ(X, Y)   = {sp.simplify(Corr_sym)} ≈ {float(Corr_sym):.6f}")
print("  → La correlación nula no implica independencia en general.")

# 9. VISUALIZACIONES

xn = np.linspace(0, 2, 120)
yn = np.linspace(0, 2, 120)
Xn, Yn = np.meshgrid(xn, yn)
Zn = (3/32) * (Xn**2 + Yn**2)

fig = plt.figure(figsize=(17, 5))
fig.suptitle("Probabilidad Conjunta Continua — Vida útil de componentes solares",
             fontsize=13, fontweight='bold')

# 9a. Superficie 3D
ax1 = fig.add_subplot(131, projection='3d')
surf = ax1.plot_surface(Xn, Yn, Zn, cmap='plasma', alpha=0.85, linewidth=0)
ax1.set_xlabel("X (panel, años)", fontsize=9)
ax1.set_ylabel("Y (inversor, años)", fontsize=9)
ax1.set_zlabel("f(x,y)", fontsize=9)
ax1.set_title("f(x,y) = (3/32)(x²+y²)", fontsize=10)
fig.colorbar(surf, ax=ax1, shrink=0.5, pad=0.1)

# 9b. Curvas de nivel (contour)
ax2 = fig.add_subplot(132)
cp = ax2.contourf(Xn, Yn, Zn, levels=15, cmap='plasma')
fig.colorbar(cp, ax=ax2)
ax2.set_xlabel("X (panel, años)", fontsize=9)
ax2.set_ylabel("Y (inversor, años)", fontsize=9)
ax2.set_title("Curvas de nivel de f(x,y)", fontsize=10)
# Región P(X+Y>2) resaltada
ax2.fill_between([0, 2], [2, 0], [2, 2], alpha=0.25, color='cyan',
                 label=f"P(X+Y>2)≈{float(P2):.3f}")
ax2.plot([0, 2], [2, 0], 'c--', linewidth=2)
ax2.legend(fontsize=9)

# 9c. Marginales
ax3 = fig.add_subplot(133)
fX_np = np.array([float(f_X_simplified.subs(x, xi)) for xi in xn])
fY_np = np.array([float(f_Y_simplified.subs(y, yi)) for yi in yn])
ax3.plot(xn, fX_np, 'steelblue', linewidth=2.5, label="f_X(x)")
ax3.plot(yn, fY_np, 'tomato', linewidth=2.5, linestyle='--', label="f_Y(y)")
ax3.set_xlabel("Valor", fontsize=9)
ax3.set_ylabel("Densidad", fontsize=9)
ax3.set_title("Densidades Marginales", fontsize=10)
ax3.legend(fontsize=9)
ax3.fill_between(xn, fX_np, alpha=0.15, color='steelblue')
ax3.fill_between(yn, fY_np, alpha=0.15, color='tomato')

plt.tight_layout()
plt.savefig("/home/claude/fig_continuo.png", dpi=150, bbox_inches='tight')
plt.close()
print("\n  [✓] Figura guardada: fig_continuo.png")
print("\n" + "=" * 65)
print("  FIN DE LA APLICACIÓN 2 — CASO CONTINUO")
print("=" * 65)
